(function(window, undefined) {
  var dictionary = {
    "e6babae5-f3b4-4af8-bc9a-270dee6b6f33": "Aprovações",
    "a369c7df-1c4a-4a5e-8a81-6662bbedbdd7": "Novo Aprovador - Etapa 2",
    "07c7c28d-fdf7-44a3-8cbb-71ed489d28f1": "Novo Aprovador - Sucesso",
    "1afbf661-7a8c-456b-bc99-d31747ab9305": "Monitor",
    "d21bf201-2b35-4722-a529-d9a6cf6edfcc": "Welcome",
    "80c94bd8-66de-4c16-b852-c81e7430178a": "Aprovação - Sucesso",
    "4f154ea3-f74d-4540-b2b9-aca316f60a78": "Novo Banco - Resumo",
    "b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9": "Novo Banco - Etapa 2",
    "5e57bcc2-695c-484c-b202-805234e521f5": "Mensagem 04",
    "ccbcc81e-e161-4546-92d2-365cf2655ee0": "Partidas em Aberto",
    "36b31db4-0170-451c-8142-456bd8908d05": "Detalhe banco",
    "9ac7a0d3-45c3-41bb-9194-bea94444f745": "Detalhe documento",
    "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8": "Mensagem 03",
    "595172c0-1cef-450d-b8b0-3fa101ffb5d1": "Novo Banco - Etapa 1",
    "deefd881-89d4-4dc7-90be-f1c034dfa928": "Bancos Lista",
    "b10dc0a7-ad45-417b-9813-768706846917": "Mensagem 01",
    "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8": "Mensagem 02",
    "d2d25b67-6109-4608-a862-d9c403f0c249": "Novo Aprovador - Resumo",
    "7ad5b76b-a541-4862-bd77-b08999632e89": "Novo Aprovador - Etapa 1",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Logon Page",
    "49aa39c4-eaf4-40ed-887b-a6f507ad46d0": "Novo Banco - Sucesso",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);