(function(window, undefined) {
  var dictionary = {
    "s-4f154ea3-f74d-4540-b2b9-aca316f60a78 s-Slice_1": [ ["Slice 1@1x.png", "ccdcccb7-c0ed-4bd0-9688-65068c51fe66_1.png"] ],
    "s-d2d25b67-6109-4608-a862-d9c403f0c249 s-Slice_1": [ ["Slice 1@1x.png", "1ef2af99-7d3f-4430-bd56-a0968a6acb8c_1.png"] ]
  };

  window.jimDevelopers.lookUpSlice = function(name) {
    var imageName;
    if(dictionary.hasOwnProperty(name)) { /* search by name */
      imageName = dictionary[name];
    }
    return imageName;
  };
})(window);