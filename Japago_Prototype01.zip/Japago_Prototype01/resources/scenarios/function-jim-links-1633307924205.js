(function(window, undefined) {

  var jimLinks = {
    "e6babae5-f3b4-4af8-bc9a-270dee6b6f33" : {
      "Text_8" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_13" : [
        "80c94bd8-66de-4c16-b852-c81e7430178a"
      ],
      "Text_26" : [
        "80c94bd8-66de-4c16-b852-c81e7430178a"
      ],
      "Text_85" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "a369c7df-1c4a-4a5e-8a81-6662bbedbdd7" : {
      "Text_8" : [
        "7ad5b76b-a541-4862-bd77-b08999632e89"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_18" : [
        "d2d25b67-6109-4608-a862-d9c403f0c249"
      ],
      "Text_63" : [
        "d2d25b67-6109-4608-a862-d9c403f0c249"
      ],
      "Text_64" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "07c7c28d-fdf7-44a3-8cbb-71ed489d28f1" : {
      "Text_2" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "1afbf661-7a8c-456b-bc99-d31747ab9305" : {
      "Text_8" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_150" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_151" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_152" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_153" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_154" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_155" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_156" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ]
    },
    "d21bf201-2b35-4722-a529-d9a6cf6edfcc" : {
      "Rectangle_8" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Paragraph_10" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Text_5" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Text_6" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Text_7" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Triangle_1" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Rectangle_9" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Paragraph_11" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Text_13" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Text_14" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Rectangle_15" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Paragraph_12" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Text_17" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Rectangle_25" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Paragraph_15" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Rectangle_26" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Paragraph_16" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Rectangle_10" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_18" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Paragraph_13" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_19" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Image_5" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Rectangle_12" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_20" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Paragraph_14" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_21" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Image_6" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Rectangle_14" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_22" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Paragraph_17" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_25" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Image_7" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Rectangle_17" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_27" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Paragraph_26" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_28" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Rectangle_29" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Paragraph_20" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_49" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Image_2" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_71" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Rectangle_30" : [
        "595172c0-1cef-450d-b8b0-3fa101ffb5d1"
      ],
      "Text_50" : [
        "595172c0-1cef-450d-b8b0-3fa101ffb5d1"
      ],
      "Image_11" : [
        "595172c0-1cef-450d-b8b0-3fa101ffb5d1"
      ],
      "Paragraph_21" : [
        "595172c0-1cef-450d-b8b0-3fa101ffb5d1"
      ],
      "Rectangle_31" : [
        "deefd881-89d4-4dc7-90be-f1c034dfa928"
      ],
      "Image_10" : [
        "deefd881-89d4-4dc7-90be-f1c034dfa928"
      ],
      "Text_72" : [
        "deefd881-89d4-4dc7-90be-f1c034dfa928"
      ],
      "Paragraph_22" : [
        "deefd881-89d4-4dc7-90be-f1c034dfa928"
      ],
      "Rectangle_28" : [
        "e6babae5-f3b4-4af8-bc9a-270dee6b6f33"
      ],
      "Paragraph_19" : [
        "e6babae5-f3b4-4af8-bc9a-270dee6b6f33"
      ],
      "Text_46" : [
        "e6babae5-f3b4-4af8-bc9a-270dee6b6f33"
      ],
      "Image_9" : [
        "e6babae5-f3b4-4af8-bc9a-270dee6b6f33"
      ],
      "Rectangle_27" : [
        "ccbcc81e-e161-4546-92d2-365cf2655ee0"
      ],
      "Paragraph_18" : [
        "ccbcc81e-e161-4546-92d2-365cf2655ee0"
      ],
      "Text_43" : [
        "ccbcc81e-e161-4546-92d2-365cf2655ee0"
      ],
      "Image_8" : [
        "ccbcc81e-e161-4546-92d2-365cf2655ee0"
      ],
      "Text_74" : [
        "ccbcc81e-e161-4546-92d2-365cf2655ee0"
      ],
      "Text_75" : [
        "e6babae5-f3b4-4af8-bc9a-270dee6b6f33"
      ],
      "Rectangle_20" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Paragraph_23" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Text_15" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Text_16" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Image_12" : [
        "1afbf661-7a8c-456b-bc99-d31747ab9305"
      ],
      "Rectangle_21" : [
        "7ad5b76b-a541-4862-bd77-b08999632e89"
      ],
      "Paragraph_24" : [
        "7ad5b76b-a541-4862-bd77-b08999632e89"
      ],
      "Text_23" : [
        "7ad5b76b-a541-4862-bd77-b08999632e89"
      ],
      "Image_13" : [
        "7ad5b76b-a541-4862-bd77-b08999632e89"
      ]
    },
    "80c94bd8-66de-4c16-b852-c81e7430178a" : {
      "Text_2" : [
        "e6babae5-f3b4-4af8-bc9a-270dee6b6f33"
      ]
    },
    "4f154ea3-f74d-4540-b2b9-aca316f60a78" : {
      "Text_8" : [
        "b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_54" : [
        "b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9"
      ],
      "Text_55" : [
        "595172c0-1cef-450d-b8b0-3fa101ffb5d1"
      ],
      "Text_67" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_13" : [
        "49aa39c4-eaf4-40ed-887b-a6f507ad46d0"
      ],
      "Text_68" : [
        "49aa39c4-eaf4-40ed-887b-a6f507ad46d0"
      ]
    },
    "b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9" : {
      "Text_8" : [
        "595172c0-1cef-450d-b8b0-3fa101ffb5d1"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_18" : [
        "4f154ea3-f74d-4540-b2b9-aca316f60a78"
      ],
      "Text_63" : [
        "4f154ea3-f74d-4540-b2b9-aca316f60a78"
      ],
      "Text_64" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "5e57bcc2-695c-484c-b202-805234e521f5" : {
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_8" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Rectangle_9" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Rectangle_10" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_4" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_34" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_35" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_37" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_40" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_41" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_43" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_46" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_47" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Image_2" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Image_7" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Image_8" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ]
    },
    "ccbcc81e-e161-4546-92d2-365cf2655ee0" : {
      "Text_8" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_83" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_125" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_126" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_127" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_128" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_129" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_130" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_131" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_132" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_133" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_134" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_135" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_136" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_137" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_138" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ],
      "Text_139" : [
        "9ac7a0d3-45c3-41bb-9194-bea94444f745"
      ]
    },
    "36b31db4-0170-451c-8142-456bd8908d05" : {
      "Text_8" : [
        "deefd881-89d4-4dc7-90be-f1c034dfa928"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "9ac7a0d3-45c3-41bb-9194-bea94444f745" : {
      "Text_8" : [
        "ccbcc81e-e161-4546-92d2-365cf2655ee0"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8" : {
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_8" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Rectangle_9" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Rectangle_10" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_4" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_34" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_35" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_37" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_40" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_41" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_49" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_52" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_53" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Image_2" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Image_7" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Image_9" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ]
    },
    "595172c0-1cef-450d-b8b0-3fa101ffb5d1" : {
      "Text_8" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_18" : [
        "b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9"
      ],
      "Text_63" : [
        "b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9"
      ],
      "Text_64" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "deefd881-89d4-4dc7-90be-f1c034dfa928" : {
      "Text_8" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_40" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Rectangle_90" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_125" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_126" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_127" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_128" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_129" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_130" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_131" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_132" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_133" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_134" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_135" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_136" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_137" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_138" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Text_139" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ],
      "Paragraph_1" : [
        "36b31db4-0170-451c-8142-456bd8908d05"
      ]
    },
    "b10dc0a7-ad45-417b-9813-768706846917" : {
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_8" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Rectangle_9" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Rectangle_10" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_37" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_40" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_41" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Text_43" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_46" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_47" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_49" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_52" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_53" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Image_7" : [
        "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8"
      ],
      "Image_8" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Image_9" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ]
    },
    "65b8cbf2-75e4-4eb7-bc60-f4e9856988e8" : {
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_8" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Rectangle_9" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Rectangle_10" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_4" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_34" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_35" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Text_43" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_46" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_47" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Text_49" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_52" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Text_53" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ],
      "Image_2" : [
        "b10dc0a7-ad45-417b-9813-768706846917"
      ],
      "Image_8" : [
        "594fd1d1-6fe6-455f-a7a7-b5da5c7551b8"
      ],
      "Image_9" : [
        "5e57bcc2-695c-484c-b202-805234e521f5"
      ]
    },
    "d2d25b67-6109-4608-a862-d9c403f0c249" : {
      "Text_8" : [
        "a369c7df-1c4a-4a5e-8a81-6662bbedbdd7"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_54" : [
        "a369c7df-1c4a-4a5e-8a81-6662bbedbdd7"
      ],
      "Text_55" : [
        "7ad5b76b-a541-4862-bd77-b08999632e89"
      ],
      "Text_67" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_13" : [
        "07c7c28d-fdf7-44a3-8cbb-71ed489d28f1"
      ],
      "Text_68" : [
        "07c7c28d-fdf7-44a3-8cbb-71ed489d28f1"
      ]
    },
    "7ad5b76b-a541-4862-bd77-b08999632e89" : {
      "Text_8" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Text_9" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ],
      "Rectangle_18" : [
        "a369c7df-1c4a-4a5e-8a81-6662bbedbdd7"
      ],
      "Text_63" : [
        "a369c7df-1c4a-4a5e-8a81-6662bbedbdd7"
      ],
      "Text_64" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    },
    "49aa39c4-eaf4-40ed-887b-a6f507ad46d0" : {
      "Text_2" : [
        "d21bf201-2b35-4722-a529-d9a6cf6edfcc"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);