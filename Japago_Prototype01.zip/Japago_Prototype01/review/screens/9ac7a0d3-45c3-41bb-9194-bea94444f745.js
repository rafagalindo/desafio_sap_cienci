var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1360" deviceHeight="896">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-9ac7a0d3-45c3-41bb-9194-bea94444f745" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Detalhe documento" width="1360" height="896">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/9ac7a0d3-45c3-41bb-9194-bea94444f745-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/9ac7a0d3-45c3-41bb-9194-bea94444f745-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/9ac7a0d3-45c3-41bb-9194-bea94444f745-1633307924205-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle_1"   datasizewidth="1360.0px" datasizeheight="896.0px" datasizewidthpx="1360.0" datasizeheightpx="896.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_5"   datasizewidth="24.0px" datasizeheight="27.0px" dataX="1258.0" dataY="12.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="50.0px" datasizeheight="26.0px" dataX="224.0" dataY="12.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/cfa4eab2-026a-4ef4-a99a-1cfcae6d378c.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image_4"   datasizewidth="34.0px" datasizeheight="34.0px" dataX="49.0" dataY="8.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c0b4c6bc-324f-4786-b8f1-19a869eccaf9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_6"   datasizewidth="20.0px" datasizeheight="27.0px" dataX="1193.0" dataY="12.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_7"   datasizewidth="21.0px" datasizeheight="27.0px" dataX="1123.0" dataY="12.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_8" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_8"   datasizewidth="12.0px" datasizeheight="27.0px" dataX="117.0" dataY="12.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_9" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_9"   datasizewidth="24.0px" datasizeheight="27.0px" dataX="167.0" dataY="12.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_10" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_10"   datasizewidth="141.4px" datasizeheight="18.0px" dataX="627.0" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_10_0">Detalhe Pagamento</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_6"   datasizewidth="1360.0px" datasizeheight="265.0px" datasizewidthpx="1360.0" datasizeheightpx="265.0" dataX="0.0" dataY="48.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_21" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_21"   datasizewidth="456.5px" datasizeheight="30.0px" dataX="48.0" dataY="72.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_21_0">Pagamento Gen&eacute;rico Fornecedor XXX</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_14" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_14"   datasizewidth="65.0px" datasizeheight="26.0px" datasizewidthpx="65.0" datasizeheightpx="26.0" dataX="1045.0" dataY="60.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_14_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_25" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_25"   datasizewidth="51.6px" datasizeheight="18.0px" dataX="1132.0" dataY="64.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_25_0">Deletar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_26" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_26"   datasizewidth="41.8px" datasizeheight="18.0px" dataX="1056.6" dataY="64.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_26_0">Editar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_31" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_31"   datasizewidth="21.3px" datasizeheight="24.0px" dataX="1265.0" dataY="61.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_31_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_3"   datasizewidth="144.0px" datasizeheight="144.0px" datasizewidthpx="144.0" datasizeheightpx="144.0" dataX="48.0" dataY="124.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="130.7px" datasizeheight="18.0px" dataX="224.0" dataY="123.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Banco: &nbsp;XYZ Bank</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_3"   datasizewidth="122.8px" datasizeheight="18.0px" dataX="224.0" dataY="147.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Data: 01/01/2021</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_4"   datasizewidth="80.0px" datasizeheight="18.0px" dataX="224.0" dataY="171.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">Multa: 10%</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_12" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_12"   datasizewidth="137.0px" datasizeheight="18.0px" dataX="401.7" dataY="123.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_12_0">Fornecedor Rating:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_13" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_13"   datasizewidth="109.4px" datasizeheight="27.0px" dataX="561.0" dataY="147.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_13_0">Agendado</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_14" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_14"   datasizewidth="49.8px" datasizeheight="18.0px" dataX="561.0" dataY="123.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_14_0">Status:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_15" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_15"   datasizewidth="37.4px" datasizeheight="18.0px" dataX="682.0" dataY="123.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_15_0">Valor</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_16" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_16"   datasizewidth="93.4px" datasizeheight="27.0px" dataX="682.0" dataY="147.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_16_0">1,459.00</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_17" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_17"   datasizewidth="17.0px" datasizeheight="15.0px" dataX="781.0" dataY="152.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_17_0">R$</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="89.0px" datasizeheight="18.0px" >\
        <div id="s-Image_6" class="pie image firer ie-background commentable non-processed" customid="Image_6"   datasizewidth="17.0px" datasizeheight="18.0px" dataX="423.0" dataY="146.0"   alt="image" systemName="./images/a04b1a26-3001-428f-9a82-c0fa18d8cf8e.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="utf-8"?>\
            	<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            	<svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_6-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            		 viewBox="0 0 500 500" style="enable-background:new 0 0 500 500;" xml:space="preserve">\
            	<style type="text/css">\
            		#s-Image_6 .st0{fill:#FDB819;}\
            	</style>\
            	<polygon id="s-Image_6-XMLID_1_" class="st0" points="250,24.1 323.4,172.8 487.5,196.7 368.8,312.4 396.8,475.9 250,398.7 103.2,475.9 \
            		131.3,312.4 12.5,196.7 176.6,172.8 "/>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_12" class="pie image firer ie-background commentable non-processed" customid="Image_12"   datasizewidth="17.0px" datasizeheight="18.0px" dataX="441.0" dataY="146.0"   alt="image" systemName="./images/dac24362-9323-4276-99f6-cddc4a777dbb.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="utf-8"?>\
            	<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            	<svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_12-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            		 viewBox="0 0 500 500" style="enable-background:new 0 0 500 500;" xml:space="preserve">\
            	<style type="text/css">\
            		#s-Image_12 .st0{fill:#FDB819;}\
            	</style>\
            	<polygon id="s-Image_12-XMLID_1_" class="st0" points="250,24.1 323.4,172.8 487.5,196.7 368.8,312.4 396.8,475.9 250,398.7 103.2,475.9 \
            		131.3,312.4 12.5,196.7 176.6,172.8 "/>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_13" class="pie image firer ie-background commentable non-processed" customid="Image_13"   datasizewidth="17.0px" datasizeheight="18.0px" dataX="459.0" dataY="146.0"   alt="image" systemName="./images/f092ea02-a372-4c8a-bc76-bcb37f7ff800.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="utf-8"?>\
            	<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            	<svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_13-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            		 viewBox="0 0 500 500" style="enable-background:new 0 0 500 500;" xml:space="preserve">\
            	<style type="text/css">\
            		#s-Image_13 .st0{fill:#FDB819;}\
            	</style>\
            	<polygon id="s-Image_13-XMLID_1_" class="st0" points="250,24.1 323.4,172.8 487.5,196.7 368.8,312.4 396.8,475.9 250,398.7 103.2,475.9 \
            		131.3,312.4 12.5,196.7 176.6,172.8 "/>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_5" class="pie image firer ie-background commentable non-processed" customid="Image_5"   datasizewidth="17.0px" datasizeheight="18.0px" dataX="477.0" dataY="146.0"   alt="image" systemName="./images/ad40cf4d-ce1d-4855-9b0d-e5b05af04335.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="utf-8"?>\
            	<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            	<svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_5-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            		 viewBox="0 0 500 500" style="enable-background:new 0 0 500 500;" xml:space="preserve">\
            	<style type="text/css">\
            		#s-Image_5 .st0{fill:#C0C0C0;}\
            	</style>\
            	<polygon id="s-Image_5-XMLID_1_" class="st0" points="250,24.1 323.4,172.8 487.5,196.7 368.8,312.4 396.8,475.9 250,398.7 103.2,475.9 \
            		131.3,312.4 12.5,196.7 176.6,172.8 "/>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_7" class="pie image firer ie-background commentable non-processed" customid="Image_7"   datasizewidth="17.0px" datasizeheight="18.0px" dataX="495.0" dataY="146.0"   alt="image" systemName="./images/4703c480-c1a3-4f79-991e-ee482e043121.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="utf-8"?>\
            	<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            	<svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_7-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            		 viewBox="0 0 500 500" style="enable-background:new 0 0 500 500;" xml:space="preserve">\
            	<style type="text/css">\
            		#s-Image_7 .st0{fill:#C0C0C0;}\
            	</style>\
            	<polygon id="s-Image_7-XMLID_1_" class="st0" points="250,24.1 323.4,172.8 487.5,196.7 368.8,312.4 396.8,475.9 250,398.7 103.2,475.9 \
            		131.3,312.4 12.5,196.7 176.6,172.8 "/>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Text_18" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_18"   datasizewidth="81.8px" datasizeheight="18.0px" dataX="48.0" dataY="287.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_18_0">Pagamento</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_19" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_19"   datasizewidth="76.5px" datasizeheight="18.0px" dataX="152.3" dataY="287.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_19_0">Aprova&ccedil;&atilde;o</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Line_2" class="pie path firer ie-background commentable non-processed" customid="Line_2"   datasizewidth="1364.0px" datasizeheight="5.0px" dataX="-0.5" dataY="310.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="1361.0" height="3.0" viewBox="-0.5 310.5 1361.0 3.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line_2-9ac7a" d="M0.0 312.0 L1360.0 312.0 "></path>\
          	    </defs>\
          	    <g>\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_2-9ac7a" fill="none" stroke-width="2.0" stroke="#D2E1EE" stroke-linecap="butt" filter="none"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Line_3" class="pie path firer ie-background commentable non-processed" customid="Line_3"   datasizewidth="44.0px" datasizeheight="5.0px" dataX="47.5" dataY="310.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="41.0" height="3.0" viewBox="47.5 310.5 41.0 3.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line_3-9ac7a" d="M48.0 312.0 L88.0 312.0 "></path>\
          	    </defs>\
          	    <g>\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_3-9ac7a" fill="none" stroke-width="2.0" stroke="#427CAC" stroke-linecap="butt" filter="none"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_22" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_22"   datasizewidth="209.5px" datasizeheight="27.0px" dataX="49.0" dataY="336.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_22_0">Pagamento 112233</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_23" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_23"   datasizewidth="209.5px" datasizeheight="27.0px" dataX="464.0" dataY="336.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_23_0">Tipo de Pagamento</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_24" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_24"   datasizewidth="74.7px" datasizeheight="27.0px" dataX="896.0" dataY="336.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_24_0">Banco:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_27" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_27"   datasizewidth="81.8px" datasizeheight="18.0px" dataX="49.0" dataY="372.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_27_0">Fornecedor</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_28" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_28"   datasizewidth="32.0px" datasizeheight="18.0px" dataX="464.0" dataY="372.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_28_0">TED</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_29" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_29"   datasizewidth="72.0px" datasizeheight="18.0px" dataX="896.0" dataY="372.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_29_0">Destin&aacute;rio</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_30" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_30"   datasizewidth="232.1px" datasizeheight="18.0px" dataX="896.0" dataY="393.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_30_0">Electronics &amp; Co. (FIO-VEND02)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_32" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_32"   datasizewidth="5.3px" datasizeheight="18.0px" dataX="464.0" dataY="393.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_32_0">-</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_33" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_33"   datasizewidth="232.1px" datasizeheight="18.0px" dataX="49.0" dataY="393.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_33_0">Electronics &amp; Co. (FIO-VEND02)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_34" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_34"   datasizewidth="80.0px" datasizeheight="18.0px" dataX="49.0" dataY="428.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_34_0">Criado Em:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_35" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_35"   datasizewidth="160.1px" datasizeheight="18.0px" dataX="464.0" dataY="428.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_35_0">Data do Agendamento</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_36" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_36"   datasizewidth="62.3px" datasizeheight="18.0px" dataX="896.0" dataY="428.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_36_0">Ag&ecirc;ncia:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_37" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_37"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="49.0" dataY="449.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_37_0">03/11/2021</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_38" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_38"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="464.0" dataY="449.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_38_0">25/12/2021</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_39" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_39"   datasizewidth="35.6px" datasizeheight="18.0px" dataX="896.0" dataY="449.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_39_0">0001</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Line_4" class="pie path firer ie-background commentable non-processed" customid="Line_4"   datasizewidth="80.0px" datasizeheight="5.0px" dataX="45.5" dataY="561.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="77.0" height="3.0" viewBox="45.5 561.5 77.0 3.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line_4-9ac7a" d="M46.0 563.0 L122.0 563.0 "></path>\
          	    </defs>\
          	    <g>\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_4-9ac7a" fill="none" stroke-width="2.0" stroke="#999999" stroke-linecap="butt" filter="none"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Line_5" class="pie path firer ie-background commentable non-processed" customid="Line_5"   datasizewidth="1364.0px" datasizeheight="5.0px" dataX="-0.5" dataY="562.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="1361.0" height="3.0" viewBox="-0.5 562.5 1361.0 3.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line_5-9ac7a" d="M0.0 564.0 L1360.0 564.0 "></path>\
          	    </defs>\
          	    <g>\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_5-9ac7a" fill="none" stroke-width="2.0" stroke="#F2F2F2" stroke-linecap="butt" filter="none"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_40" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_40"   datasizewidth="114.7px" datasizeheight="27.0px" dataX="48.0" dataY="532.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_40_0">Aprova&ccedil;&atilde;o</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_41" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_41"   datasizewidth="69.4px" datasizeheight="27.0px" dataX="49.0" dataY="626.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_41_0">Dados</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_42" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_42"   datasizewidth="84.1px" datasizeheight="27.0px" dataX="464.0" dataY="626.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_42_0">Contato</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_43" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_43"   datasizewidth="102.7px" datasizeheight="27.0px" dataX="896.0" dataY="626.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_43_0">Endere&ccedil;o</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_44" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_44"   datasizewidth="101.4px" datasizeheight="18.0px" dataX="49.0" dataY="662.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_44_0">Departamento</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_45" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_45"   datasizewidth="44.5px" datasizeheight="18.0px" dataX="464.0" dataY="662.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_45_0">Email:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_46" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_46"   datasizewidth="79.2px" datasizeheight="18.0px" dataX="896.0" dataY="662.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_46_0">Subsidi&aacute;ria</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_47" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_47"   datasizewidth="5.3px" datasizeheight="18.0px" dataX="896.0" dataY="683.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_47_0">-</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_48" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_48"   datasizewidth="160.3px" datasizeheight="18.0px" dataX="464.0" dataY="683.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_48_0">mark.brown@test.com</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_49" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_49"   datasizewidth="169.0px" datasizeheight="18.0px" dataX="49.0" dataY="683.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_49_0">Product &amp; Development</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_50" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_50"   datasizewidth="121.0px" datasizeheight="18.0px" dataX="49.0" dataY="718.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_50_0">Centro de Custo:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_51" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_51"   datasizewidth="66.7px" datasizeheight="18.0px" dataX="464.0" dataY="718.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_51_0">Telefone:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_52" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_52"   datasizewidth="66.7px" datasizeheight="18.0px" dataX="896.0" dataY="718.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_52_0">Escrit&oacute;rio</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_53" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_53"   datasizewidth="99.6px" datasizeheight="18.0px" dataX="49.0" dataY="739.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_53_0">P&amp;D 103.23.4</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_54" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_54"   datasizewidth="125.0px" datasizeheight="18.0px" dataX="464.0" dataY="739.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_54_0">+1283907420357</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_55" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_55"   datasizewidth="110.3px" datasizeheight="18.0px" dataX="896.0" dataY="739.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_55_0">EC02-Brussells</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_56" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_56"   datasizewidth="230.8px" datasizeheight="27.0px" dataX="49.0" dataY="579.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_56_0">Fulanelson Apolin&aacute;rio</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_57" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_57"   datasizewidth="57.8px" datasizeheight="18.0px" dataX="48.0" dataY="780.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_57_0">Gerente</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_58" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_58"   datasizewidth="55.1px" datasizeheight="18.0px" dataX="463.0" dataY="780.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_58_0">Celular:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_60" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_60"   datasizewidth="103.2px" datasizeheight="18.0px" dataX="48.0" dataY="801.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_60_0">Michel Leclerq</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_61" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_61"   datasizewidth="133.9px" datasizeheight="18.0px" dataX="463.0" dataY="801.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_61_0">+10183979233837</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Line_6" class="pie path firer ie-background commentable non-processed" customid="Line_6"   datasizewidth="1364.0px" datasizeheight="5.0px" dataX="-0.5" dataY="869.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="1361.0" height="3.0" viewBox="-0.5 869.5 1361.0 3.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line_6-9ac7a" d="M0.0 871.0 L1360.0 871.0 "></path>\
          	    </defs>\
          	    <g>\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_6-9ac7a" fill="none" stroke-width="2.0" stroke="#F2F2F2" stroke-linecap="butt" filter="none"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_124" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_36"   datasizewidth="47.1px" datasizeheight="18.0px" dataX="1000.7" dataY="428.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_124_0">Conta:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_125" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_39"   datasizewidth="76.5px" datasizeheight="18.0px" dataX="1006.5" dataY="446.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_125_0">2541368-5</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;