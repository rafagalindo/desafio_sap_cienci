var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1360" deviceHeight="896">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Novo Banco - Etapa 2" width="1360" height="896">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/b1baf6dc-c515-48ba-97ac-8fb9dde9e1d9-1633307924205-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_44" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1360.0px" datasizeheight="896.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle_1"   datasizewidth="1360.0px" datasizeheight="896.0px" datasizewidthpx="1360.0" datasizeheightpx="896.0" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="1360.0px" datasizeheight="848.0px" datasizewidthpx="1360.0" datasizeheightpx="848.0" dataX="0.0" dataY="48.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_5"   datasizewidth="24.0px" datasizeheight="27.0px" dataX="1258.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="50.0px" datasizeheight="26.0px" dataX="224.0" dataY="12.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/444ae159-3fb2-4e98-b0f5-346dedd09e75.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image_4"   datasizewidth="34.0px" datasizeheight="34.0px" dataX="49.0" dataY="8.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/22a49b5f-58ae-42a5-b7ae-00fbf6609cc5.jpg" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Text_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_6"   datasizewidth="20.0px" datasizeheight="27.0px" dataX="1193.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_6_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_7"   datasizewidth="21.0px" datasizeheight="27.0px" dataX="1123.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_8" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_8"   datasizewidth="12.0px" datasizeheight="27.0px" dataX="117.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_8_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_9" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_9"   datasizewidth="24.0px" datasizeheight="27.0px" dataX="167.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_9_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_10" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_10"   datasizewidth="87.2px" datasizeheight="18.0px" dataX="622.2" dataY="16.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_10_0">Novo Banco</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_17" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_17"   datasizewidth="1344.0px" datasizeheight="40.0px" datasizewidthpx="1344.0" datasizeheightpx="40.0" dataX="8.0" dataY="848.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_17_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_18" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_18"   datasizewidth="143.0px" datasizeheight="32.0px" datasizewidthpx="143.0" datasizeheightpx="32.0" dataX="264.0" dataY="308.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_18_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_63" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_63"   datasizewidth="58.7px" datasizeheight="18.0px" dataX="303.7" dataY="315.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_63_0">Avan&ccedil;ar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_64" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_64"   datasizewidth="64.0px" datasizeheight="18.0px" dataX="1274.0" dataY="859.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_64_0">Cancelar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_3"   datasizewidth="1360.0px" datasizeheight="64.0px" datasizewidthpx="1360.0" datasizeheightpx="64.0" dataX="0.0" dataY="48.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_8" class="pie path firer ie-background commentable non-processed" customid="Line_8"   datasizewidth="1364.0px" datasizeheight="5.0px" dataX="-0.5" dataY="109.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="1361.0" height="3.0" viewBox="-0.5 109.5 1361.0 3.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_8-b1baf" d="M0.0 111.0 L1360.0 111.0 "></path>\
            	    </defs>\
            	    <g>\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_8-b1baf" fill="none" stroke-width="2.0" stroke="#D2E1EE" stroke-linecap="butt" filter="none"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_2" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="36.0px" datasizeheight="36.0px" datasizewidthpx="36.0" datasizeheightpx="36.0" dataX="89.0" dataY="62.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0">1</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_3" customid="Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="36.0px" datasizeheight="36.0px" datasizewidthpx="36.0" datasizeheightpx="36.0" dataX="297.0" dataY="62.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_3)">\
                            <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_3" cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                            <ellipse cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_3" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_3_0">2</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_4" customid="Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="36.0px" datasizeheight="36.0px" datasizewidthpx="36.0" datasizeheightpx="36.0" dataX="505.0" dataY="62.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_4)">\
                            <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_4" cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                            <ellipse cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_4" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_4_0">3</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Text_4" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Text_4"   datasizewidth="98.0px" datasizeheight="30.0px" dataX="548.0" dataY="65.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_4_0">Resumo</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_4" class="pie path firer ie-background commentable non-processed" customid="Line_4"   datasizewidth="115.0px" datasizeheight="5.0px" dataX="59.5" dataY="109.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="112.0" height="3.0" viewBox="59.5 109.5 112.0 3.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_4-b1baf" d="M60.0 111.0 L171.0 111.0 "></path>\
            	    </defs>\
            	    <g>\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_4-b1baf" fill="none" stroke-width="2.0" stroke="#427CAC" stroke-linecap="butt" filter="none"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_12" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_12"   datasizewidth="51.1px" datasizeheight="15.0px" dataX="340.0" dataY="73.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_12_0">Servi&ccedil;os</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_5" class="pie path firer ie-background commentable non-processed" customid="Line_5"   datasizewidth="67.0px" datasizeheight="3.0px" dataX="431.5" dataY="79.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="66.0" height="2.0" viewBox="431.5 79.0 66.0 2.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_5-b1baf" d="M432.0 80.0 L497.0 80.0 "></path>\
            	    </defs>\
            	    <g>\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_5-b1baf" fill="none" stroke-width="1.0" stroke="#427CAC" stroke-linecap="butt" filter="none"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_6" class="pie path firer ie-background commentable non-processed" customid="Line_6"   datasizewidth="57.0px" datasizeheight="3.0px" dataX="233.5" dataY="79.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="56.0" height="2.0" viewBox="233.5 79.0 56.0 2.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_6-b1baf" d="M234.0 80.0 L289.0 80.0 "></path>\
            	    </defs>\
            	    <g>\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_6-b1baf" fill="none" stroke-width="1.0" stroke="#427CAC" stroke-linecap="butt" filter="none"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_13" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_13"   datasizewidth="35.6px" datasizeheight="15.0px" dataX="132.0" dataY="73.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_13_0">Conta</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_14" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_14"   datasizewidth="118.7px" datasizeheight="27.0px" dataX="14.0" dataY="128.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_14_0">2. Servi&ccedil;os</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_5" customid="Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="36.0px" datasizeheight="36.0px" datasizewidthpx="36.0" datasizeheightpx="36.0" dataX="505.0" dataY="62.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_5)">\
                            <ellipse id="s-Ellipse_5" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_3" cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                            <ellipse cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_5" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_5_0">3</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_9" customid="Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_9 non-processed"   datasizewidth="36.0px" datasizeheight="36.0px" datasizewidthpx="36.0" datasizeheightpx="36.0" dataX="297.0" dataY="62.5" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_9" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_9)">\
                            <ellipse id="s-Ellipse_9" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_4" cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_9" class="clipPath">\
                            <ellipse cx="18.0" cy="18.0" rx="18.0" ry="18.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_9" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_9_0">2</span>\
                    </div>\
                </div>\
            </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Group 8" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="150.0px" datasizeheight="64.0px" >\
          <div id="s-Rectangle_15" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_15"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="139.0" dataY="221.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_15_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="32.0px" datasizeheight="18.0px" dataX="171.0" dataY="221.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_2_0">TED</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_16" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_16"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="139.0" dataY="267.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_16_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_3"   datasizewidth="25.8px" datasizeheight="18.0px" dataX="171.0" dataY="267.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_3_0">PIX</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_42" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_42"   datasizewidth="9.8px" datasizeheight="13.0px" dataX="142.0" dataY="269.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_42_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="150.0px" datasizeheight="64.0px" >\
          <div id="s-Rectangle_19" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_15"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="231.0" dataY="221.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_19_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_11" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="64.9px" datasizeheight="18.0px" dataX="263.0" dataY="221.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_11_0">BOLETO</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_20" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_16"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="231.0" dataY="267.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_20_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_15" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_3"   datasizewidth="73.8px" datasizeheight="18.0px" dataX="263.0" dataY="267.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_15_0">D&eacute;bito CC</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_43" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_42"   datasizewidth="9.8px" datasizeheight="13.0px" dataX="234.0" dataY="269.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_43_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Text_16" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_15"   datasizewidth="344.2px" datasizeheight="18.0px" dataX="139.0" dataY="187.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_16_0">*Servi&ccedil;os dispon&iacute;veis para o banco selecionado</span><span id="rtr-s-Text_16_1">:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;