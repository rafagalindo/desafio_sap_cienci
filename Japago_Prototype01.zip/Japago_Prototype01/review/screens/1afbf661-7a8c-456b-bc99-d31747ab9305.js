var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1360" deviceHeight="1393">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-1afbf661-7a8c-456b-bc99-d31747ab9305" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Monitor" width="1360" height="1393">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/1afbf661-7a8c-456b-bc99-d31747ab9305-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/1afbf661-7a8c-456b-bc99-d31747ab9305-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/1afbf661-7a8c-456b-bc99-d31747ab9305-1633307924205-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_236" class="group firer ie-background commentable non-processed" customid="Group_5" datasizewidth="1360.0px" datasizeheight="1393.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle_1"   datasizewidth="1360.0px" datasizeheight="896.0px" datasizewidthpx="1360.0" datasizeheightpx="896.0" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="1360.0px" datasizeheight="1066.0px" datasizewidthpx="1360.0" datasizeheightpx="1066.0" dataX="0.0" dataY="327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_5"   datasizewidth="24.0px" datasizeheight="27.0px" dataX="1258.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="50.0px" datasizeheight="26.0px" dataX="224.0" dataY="12.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/5ee81e3a-bf70-4439-b942-ba545ff96c23.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_4" class="pie image firer ie-background commentable non-processed" customid="Image_4"   datasizewidth="34.0px" datasizeheight="34.0px" dataX="49.0" dataY="8.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/123eb217-935a-43c4-bcd0-37854f2556e9.jpg" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Text_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_6"   datasizewidth="20.0px" datasizeheight="27.0px" dataX="1193.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_6_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_7"   datasizewidth="21.0px" datasizeheight="27.0px" dataX="1123.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_8" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_8"   datasizewidth="12.0px" datasizeheight="27.0px" dataX="117.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_8_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_9" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_9"   datasizewidth="24.0px" datasizeheight="27.0px" dataX="167.0" dataY="12.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_9_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_10" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_10"   datasizewidth="62.2px" datasizeheight="18.0px" dataX="648.9" dataY="16.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_10_0">Hist&oacute;rico</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Group_4" datasizewidth="1360.0px" datasizeheight="279.0px" >\
          <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_3"   datasizewidth="1360.0px" datasizeheight="278.0px" datasizewidthpx="1360.0" datasizeheightpx="278.0" dataX="0.0" dataY="48.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_3_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_12" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_12"   datasizewidth="281.7px" datasizeheight="30.0px" dataX="45.0" dataY="77.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_12_0">An&aacute;lise de Pagamentos</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_7"   datasizewidth="39.0px" datasizeheight="30.0px" datasizewidthpx="39.0" datasizeheightpx="30.0" dataX="1242.0" dataY="72.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_7_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_8" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_8"   datasizewidth="35.0px" datasizeheight="30.0px" datasizewidthpx="35.0" datasizeheightpx="30.0" dataX="1280.0" dataY="72.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_8_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_17" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_17"   datasizewidth="67.6px" datasizeheight="18.0px" dataX="1071.0" dataY="80.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_17_0">Filtros (3)</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_18" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_18"   datasizewidth="16.0px" datasizeheight="18.0px" dataX="1191.0" dataY="81.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_18_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_19" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_19"   datasizewidth="288.2px" datasizeheight="18.0px" dataX="45.0" dataY="138.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_19_0">Pagamentos Conclu&iacute;dos por Fornecedor</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_22" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_22"   datasizewidth="247.2px" datasizeheight="18.0px" dataX="457.0" dataY="138.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_22_0">Pagamentos realizado com &nbsp;atraso</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_23" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_23"   datasizewidth="162.7px" datasizeheight="18.0px" dataX="852.0" dataY="138.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_23_0">Distribui&ccedil;&atilde;o Por Banco</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_24" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_24"   datasizewidth="120.1px" datasizeheight="18.0px" dataX="1122.0" dataY="138.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_24_0">Selecionados (5)</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_16" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_16"   datasizewidth="367.0px" datasizeheight="39.0px" datasizewidthpx="367.0" datasizeheightpx="39.0" dataX="45.0" dataY="180.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_16_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_27" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_27"   datasizewidth="54.1px" datasizeheight="15.0px" dataX="54.0" dataY="191.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_27_0">KJS Top</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_17" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_17"   datasizewidth="197.0px" datasizeheight="26.0px" datasizewidthpx="197.0" datasizeheightpx="26.0" dataX="168.0" dataY="187.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_17_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_28" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_28"   datasizewidth="37.8px" datasizeheight="15.0px" dataX="311.0" dataY="192.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_28_0">80,2%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_29" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_29"   datasizewidth="95.6px" datasizeheight="15.0px" dataX="54.0" dataY="229.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_29_0">Akron Heating ..</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_30" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_30"   datasizewidth="92.6px" datasizeheight="15.0px" dataX="54.0" dataY="268.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_30_0">Silverstar Syst..</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_18" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_18"   datasizewidth="210.0px" datasizeheight="26.0px" datasizewidthpx="210.0" datasizeheightpx="26.0" dataX="168.0" dataY="226.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_18_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_19" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_19"   datasizewidth="221.0px" datasizeheight="26.0px" datasizewidthpx="221.0" datasizeheightpx="26.0" dataX="168.0" dataY="265.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_19_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_32" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_32"   datasizewidth="37.8px" datasizeheight="15.0px" dataX="321.0" dataY="231.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_32_0">85,4%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_33" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_33"   datasizewidth="37.8px" datasizeheight="15.0px" dataX="331.0" dataY="270.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_33_0">90,5%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_34" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_34"   datasizewidth="34.0px" datasizeheight="13.0px" dataX="460.0" dataY="180.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_34_0">33,1%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_35" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_35"   datasizewidth="34.0px" datasizeheight="13.0px" dataX="524.0" dataY="183.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_35_0">31,7%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_36" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_36"   datasizewidth="34.0px" datasizeheight="13.0px" dataX="588.0" dataY="186.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_36_0">30,1%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_37" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_37"   datasizewidth="34.0px" datasizeheight="13.0px" dataX="652.0" dataY="191.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_37_0">29,8%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_38" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_38"   datasizewidth="34.0px" datasizeheight="13.0px" dataX="716.0" dataY="190.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_38_0">28,9%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_39" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_39"   datasizewidth="27.4px" datasizeheight="13.0px" dataX="783.0" dataY="225.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_39_0">7,8%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Line_4" class="pie path firer ie-background commentable non-processed" customid="Line_4"   datasizewidth="349.0px" datasizeheight="3.0px" dataX="461.5" dataY="270.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="348.0" height="2.0" viewBox="461.5 270.0 348.0 2.0" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Line_4-1afbf" d="M462.0 271.0 L809.0 271.0 "></path>\
              	    </defs>\
              	    <g>\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_4-1afbf" fill="none" stroke-width="1.0" stroke="#434343" stroke-linecap="butt" filter="none"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_40" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_40"   datasizewidth="19.3px" datasizeheight="13.0px" dataX="467.0" dataY="276.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_40_0">Mai</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_41" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_41"   datasizewidth="19.3px" datasizeheight="13.0px" dataX="531.0" dataY="276.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_41_0">Jun</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_42" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_42"   datasizewidth="15.3px" datasizeheight="13.0px" dataX="597.0" dataY="276.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_42_0">Jul</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_43" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_43"   datasizewidth="21.4px" datasizeheight="13.0px" dataX="659.0" dataY="276.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_43_0">Ago</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_44" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_44"   datasizewidth="18.0px" datasizeheight="13.0px" dataX="722.0" dataY="276.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_44_0">Set</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_45" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_45"   datasizewidth="19.3px" datasizeheight="13.0px" dataX="788.0" dataY="276.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_45_0">Out</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Line_5" class="pie path firer ie-background commentable non-processed" customid="Line_5"   datasizewidth="63.0px" datasizeheight="4.1px" dataX="477.5" dataY="210.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="61.997772216796875" height="4.128265380859375" viewBox="477.482549374473 210.0003019589966 61.997772216796875 4.128265380859375" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Line_5-1afbf" d="M478.0 211.0 L538.9628404481648 213.12886929885255 "></path>\
              	    </defs>\
              	    <g>\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_5-1afbf" fill="none" stroke-width="1.0" stroke="#0F7DAF" stroke-linecap="butt" filter="none"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Line_6" class="pie path firer ie-background commentable non-processed" customid="Line_6"   datasizewidth="66.0px" datasizeheight="3.1px" dataX="540.5" dataY="213.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="65.0076904296875" height="3.116790771484375" viewBox="540.4912810301607 213.00008162025088 65.0076904296875 3.116790771484375" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Line_6-1afbf" d="M541.0 214.0 L604.9902524900091 215.11695401198614 "></path>\
              	    </defs>\
              	    <g>\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_6-1afbf" fill="none" stroke-width="1.0" stroke="#0F7DAF" stroke-linecap="butt" filter="none"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Line_7" class="pie path firer ie-background commentable non-processed" customid="Line_7"   datasizewidth="66.0px" datasizeheight="3.1px" dataX="604.5" dataY="214.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="65.0076904296875" height="3.116790771484375" viewBox="604.4912810301607 214.00008162025088 65.0076904296875 3.116790771484375" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Line_7-1afbf" d="M605.0 215.0 L668.9902524900091 216.11695401198614 "></path>\
              	    </defs>\
              	    <g>\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_7-1afbf" fill="none" stroke-width="1.0" stroke="#0F7DAF" stroke-linecap="butt" filter="none"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Line_8" class="pie path firer ie-background commentable non-processed" customid="Line_8"   datasizewidth="66.0px" datasizeheight="3.0px" dataX="668.5" dataY="214.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="65.0" height="2.0" viewBox="668.5 214.0 65.0 2.0" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Line_8-1afbf" d="M669.0 215.0 L733.0 215.0 "></path>\
              	    </defs>\
              	    <g>\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_8-1afbf" fill="none" stroke-width="1.0" stroke="#0F7DAF" stroke-linecap="butt" filter="none"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Line_9" class="pie path firer ie-background commentable non-processed" customid="Line_9"   datasizewidth="64.3px" datasizeheight="45.6px" dataX="733.2" dataY="214.1"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="63.8292236328125" height="45.41094970703125" viewBox="733.2131658665754 214.09042972782413 63.8292236328125 45.41094970703125" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Line_9-1afbf" d="M734.0 215.0 L796.2555553659633 258.5918091626795 "></path>\
              	    </defs>\
              	    <g>\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_9-1afbf" fill="none" stroke-width="1.0" stroke="#0F7DAF" stroke-linecap="butt" filter="none"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_1" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="8.0px" datasizeheight="8.0px" datasizewidthpx="8.0" datasizeheightpx="8.0" dataX="473.0" dataY="207.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_1)">\
                              <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                              <ellipse cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_1" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_1_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_2" customid="Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="8.0px" datasizeheight="8.0px" datasizewidthpx="8.0" datasizeheightpx="8.0" dataX="537.0" dataY="210.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_2)">\
                              <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_2" cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                              <ellipse cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_2" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_2_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_3" customid="Ellipse_3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="8.0px" datasizeheight="8.0px" datasizewidthpx="8.0" datasizeheightpx="8.0" dataX="601.0" dataY="211.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_3)">\
                              <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_3" cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                              <ellipse cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_3" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_3_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_4" customid="Ellipse_4" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="8.0px" datasizeheight="8.0px" datasizewidthpx="8.0" datasizeheightpx="8.0" dataX="665.0" dataY="212.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_4)">\
                              <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_4" cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                              <ellipse cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_4" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_4_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_5" customid="Ellipse_5" class="shapewrapper shapewrapper-s-Ellipse_5 non-processed"   datasizewidth="8.0px" datasizeheight="8.0px" datasizewidthpx="8.0" datasizeheightpx="8.0" dataX="729.0" dataY="211.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_5" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_5)">\
                              <ellipse id="s-Ellipse_5" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_5" cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_5" class="clipPath">\
                              <ellipse cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_5" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_5_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="shapewrapper-s-Ellipse_6" customid="Ellipse_6" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="8.0px" datasizeheight="8.0px" datasizewidthpx="8.0" datasizeheightpx="8.0" dataX="793.0" dataY="256.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_6)">\
                              <ellipse id="s-Ellipse_6" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_6" cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                              <ellipse cx="4.0" cy="4.0" rx="4.0" ry="4.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_6" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_6_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Rectangle_20" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_20"   datasizewidth="14.0px" datasizeheight="14.0px" datasizewidthpx="14.0" datasizeheightpx="14.0" dataX="1053.0" dataY="182.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_20_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_21" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_21"   datasizewidth="14.0px" datasizeheight="14.0px" datasizewidthpx="14.0" datasizeheightpx="14.0" dataX="1053.0" dataY="225.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_21_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_22" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_22"   datasizewidth="14.0px" datasizeheight="14.0px" datasizewidthpx="14.0" datasizeheightpx="14.0" dataX="1053.0" dataY="268.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_22_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_46" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_46"   datasizewidth="116.4px" datasizeheight="15.0px" dataX="1077.0" dataY="181.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_46_0">Banco 1: &nbsp; &nbsp; &nbsp; 40,0%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_47" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_47"   datasizewidth="116.4px" datasizeheight="15.0px" dataX="1077.0" dataY="224.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_47_0">Banco 2: &nbsp; &nbsp; &nbsp; 35,5%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Text_48" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_48"   datasizewidth="118.6px" datasizeheight="15.0px" dataX="1077.0" dataY="267.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Text_48_0">Outros: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;21,5%</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_23" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_23"   datasizewidth="35.0px" datasizeheight="47.0px" datasizewidthpx="35.0" datasizeheightpx="47.0" dataX="1325.0" dataY="163.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_23_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_24" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_24" rotationdeg="180.0"  datasizewidth="35.0px" datasizeheight="47.0px" datasizewidthpx="35.0" datasizeheightpx="47.0" dataX="1.0" dataY="164.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_24_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="180.0px" datasizeheight="140.0px" dataX="850.0" dataY="162.0"   alt="image" systemName="./images/aea5fb35-a02d-4c09-b248-5362dc1a30c1.svg" overlay="">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="utf-8"?>\
              	<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
              	<svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_1-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
              		 viewBox="0 0 792 612" style="enable-background:new 0 0 792 612;" xml:space="preserve">\
              	<style type="text/css">\
              		#s-Image_1 .st0{fill:#55A1C4;}\
              		#s-Image_1 .st1{fill:#427CAD;}\
              		#s-Image_1 .st2{fill:#8CBDD4;}\
              	</style>\
              	<path id="s-Image_1-XMLID_9_" class="st0" d="M397,57c-138.1,0-250,111.9-250,250s111.9,250,250,250s250-111.9,250-250S535.1,57,397,57z\
              		 M397,485.6c-98.6,0-178.6-79.9-178.6-178.6s80-178.6,178.6-178.6s178.6,80,178.6,178.6S495.6,485.6,397,485.6z"/>\
              	<path id="s-Image_1-XMLID_16_" class="st1" d="M396.6,128.7c98.3,0.3,178,80.1,178,178.6c0,49.1-19.8,93.6-52,125.9l50.5,50.5\
              		c45-45.2,72.9-107.6,72.9-176.4c0-137.9-111.6-249.7-249.4-250V128.7z"/>\
              	<path id="s-Image_1-XMLID_3_" class="st2" d="M396.6,128.7c-98.3,0.3-178,80.1-178,178.6c0,49.1,19.8,93.6,52,125.9l-50.5,50.5\
              		c-45-45.2-72.9-107.6-72.9-176.4c0-137.9,111.6-249.7,249.4-250V128.7z"/>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Line_2" class="pie path firer ie-background commentable non-processed" customid="Line_2"   datasizewidth="1364.0px" datasizeheight="5.0px" dataX="-0.5" dataY="324.5"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="1361.0" height="3.0" viewBox="-0.5 324.5 1361.0 3.0" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Line_2-1afbf" d="M0.0 326.0 L1360.0 326.0 "></path>\
              	    </defs>\
              	    <g>\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_2-1afbf" fill="none" stroke-width="2.0" stroke="#D2E1EE" stroke-linecap="butt" filter="none"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Text_82" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_82"   datasizewidth="134.9px" datasizeheight="30.0px" dataX="55.0" dataY="881.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_82_0">Items (127)</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_74" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_74"   datasizewidth="31.0px" datasizeheight="32.0px" datasizewidthpx="31.0" datasizeheightpx="32.0" dataX="1211.0" dataY="355.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_74_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_75" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_75"   datasizewidth="32.0px" datasizeheight="32.0px" datasizewidthpx="32.0" datasizeheightpx="32.0" dataX="1241.0" dataY="355.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_75_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_84" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_84"   datasizewidth="18.7px" datasizeheight="21.0px" dataX="1192.0" dataY="883.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_84_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_85" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_85"   datasizewidth="18.7px" datasizeheight="21.0px" dataX="1231.0" dataY="884.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_85_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_86" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_86"   datasizewidth="16.2px" datasizeheight="21.0px" dataX="1270.0" dataY="884.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_86_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_146" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_146"   datasizewidth="1307.0px" datasizeheight="40.0px" datasizewidthpx="1307.0" datasizeheightpx="40.0" dataX="34.0" dataY="924.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_146_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_1" class="pie path firer ie-background commentable non-processed" customid="Line_1"   datasizewidth="3.0px" datasizeheight="258.0px" dataX="199.0" dataY="487.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="2.0" height="257.0" viewBox="199.0 487.5 2.0 257.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_1-1afbf" d="M200.0 488.0 L200.00000000000003 744.0 "></path>\
            	    </defs>\
            	    <g>\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_1-1afbf" fill="none" stroke-width="1.0" stroke="#797979" stroke-linecap="butt" filter="none"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_154" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_154"   datasizewidth="979.0px" datasizeheight="39.0px" datasizewidthpx="979.0" datasizeheightpx="39.0" dataX="200.0" dataY="503.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_154_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_156" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_156"   datasizewidth="898.0px" datasizeheight="39.0px" datasizewidthpx="898.0" datasizeheightpx="39.0" dataX="200.0" dataY="503.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_156_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_157" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_157"   datasizewidth="872.0px" datasizeheight="39.0px" datasizewidthpx="872.0" datasizeheightpx="39.0" dataX="200.0" dataY="503.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_157_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_158" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_158"   datasizewidth="549.0px" datasizeheight="39.0px" datasizewidthpx="549.0" datasizeheightpx="39.0" dataX="200.0" dataY="503.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_158_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_167" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_167"   datasizewidth="728.4px" datasizeheight="18.0px" dataX="55.0" dataY="400.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_167_0">Todos Pagamentos: Fornecedor / Tipo de Pagamento / Banco / Pagamento Realizado / Por Aprovador</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_168" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_168"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="55.0" dataY="514.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_168_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_169" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_169"   datasizewidth="108.5px" datasizeheight="18.0px" dataX="55.0" dataY="561.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_169_0">Laurent Dubois</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_170" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_170"   datasizewidth="66.7px" datasizeheight="18.0px" dataX="55.0" dataY="608.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_170_0">Kathy Liu</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_171" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_171"   datasizewidth="100.5px" datasizeheight="18.0px" dataX="55.0" dataY="654.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_171_0">Elena Petrova</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_172" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_172"   datasizewidth="89.8px" datasizeheight="18.0px" dataX="55.0" dataY="700.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_172_0">Gerd Becker</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_186" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_186"   datasizewidth="25.8px" datasizeheight="18.0px" dataX="75.0" dataY="788.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_186_0">PIX</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_187" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_187"   datasizewidth="32.0px" datasizeheight="18.0px" dataX="210.0" dataY="788.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_187_0">TED</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_188" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_188"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="354.0" dataY="788.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_188_0">Boleto</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_189" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_189"   datasizewidth="46.3px" datasizeheight="18.0px" dataX="493.0" dataY="788.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_189_0">D&eacute;bito</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_159" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_159"   datasizewidth="107.0px" datasizeheight="39.0px" datasizewidthpx="107.0" datasizeheightpx="39.0" dataX="200.0" dataY="550.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_159_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_161" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_161"   datasizewidth="98.0px" datasizeheight="39.0px" datasizewidthpx="98.0" datasizeheightpx="39.0" dataX="200.0" dataY="550.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_161_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_162" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_162"   datasizewidth="74.0px" datasizeheight="39.0px" datasizewidthpx="74.0" datasizeheightpx="39.0" dataX="200.0" dataY="550.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_162_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_163" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_163"   datasizewidth="60.0px" datasizeheight="39.0px" datasizewidthpx="60.0" datasizeheightpx="39.0" dataX="200.0" dataY="550.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_163_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_166" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_166"   datasizewidth="82.0px" datasizeheight="39.0px" datasizewidthpx="82.0" datasizeheightpx="39.0" dataX="200.0" dataY="597.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_166_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_167" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_167"   datasizewidth="34.0px" datasizeheight="39.0px" datasizewidthpx="34.0" datasizeheightpx="39.0" dataX="200.0" dataY="597.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_167_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_168" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_168"   datasizewidth="23.0px" datasizeheight="39.0px" datasizewidthpx="23.0" datasizeheightpx="39.0" dataX="200.0" dataY="597.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_168_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_169" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_169"   datasizewidth="74.0px" datasizeheight="39.0px" datasizewidthpx="74.0" datasizeheightpx="39.0" dataX="200.0" dataY="643.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_169_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_171" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_171"   datasizewidth="8.0px" datasizeheight="39.0px" datasizewidthpx="8.0" datasizeheightpx="39.0" dataX="200.0" dataY="643.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_171_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_164" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_164"   datasizewidth="27.0px" datasizeheight="39.0px" datasizewidthpx="27.0" datasizeheightpx="39.0" dataX="200.0" dataY="689.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_164_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_172" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_172"   datasizewidth="16.0px" datasizeheight="39.0px" datasizewidthpx="16.0" datasizeheightpx="39.0" dataX="200.0" dataY="689.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_172_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_7" customid="Ellipse_7" class="shapewrapper shapewrapper-s-Ellipse_7 non-processed"   datasizewidth="11.0px" datasizeheight="11.0px" datasizewidthpx="11.0" datasizeheightpx="11.0" dataX="55.0" dataY="791.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_7" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_7)">\
                            <ellipse id="s-Ellipse_7" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_7" cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_7" class="clipPath">\
                            <ellipse cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_7" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_7_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_8" customid="Ellipse_8" class="shapewrapper shapewrapper-s-Ellipse_8 non-processed"   datasizewidth="11.0px" datasizeheight="11.0px" datasizewidthpx="11.0" datasizeheightpx="11.0" dataX="191.0" dataY="791.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_8" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_8)">\
                            <ellipse id="s-Ellipse_8" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_8" cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_8" class="clipPath">\
                            <ellipse cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_8" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_8_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_9" customid="Ellipse_9" class="shapewrapper shapewrapper-s-Ellipse_9 non-processed"   datasizewidth="11.0px" datasizeheight="11.0px" datasizewidthpx="11.0" datasizeheightpx="11.0" dataX="334.0" dataY="791.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_9" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_9)">\
                            <ellipse id="s-Ellipse_9" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_9" cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_9" class="clipPath">\
                            <ellipse cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_9" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_9_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="shapewrapper-s-Ellipse_10" customid="Ellipse_10" class="shapewrapper shapewrapper-s-Ellipse_10 non-processed"   datasizewidth="11.0px" datasizeheight="11.0px" datasizewidthpx="11.0" datasizeheightpx="11.0" dataX="475.0" dataY="791.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_10" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_10)">\
                            <ellipse id="s-Ellipse_10" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_10" cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_10" class="clipPath">\
                            <ellipse cx="5.5" cy="5.5" rx="5.5" ry="5.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="paddingLayer">\
                <div id="shapert-s-Ellipse_10" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_10_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Text_97" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_97"   datasizewidth="14.0px" datasizeheight="18.0px" dataX="1037.0" dataY="362.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_97_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_148" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_148"   datasizewidth="1306.0px" datasizeheight="51.0px" datasizewidthpx="1306.0" datasizeheightpx="51.0" dataX="35.0" dataY="1010.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_148_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_149" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_149"   datasizewidth="1306.0px" datasizeheight="51.0px" datasizewidthpx="1306.0" datasizeheightpx="51.0" dataX="35.0" dataY="1060.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_149_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_150" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_150"   datasizewidth="1306.0px" datasizeheight="51.0px" datasizewidthpx="1306.0" datasizeheightpx="51.0" dataX="35.0" dataY="1110.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_150_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_151" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_151"   datasizewidth="1306.0px" datasizeheight="51.0px" datasizewidthpx="1306.0" datasizeheightpx="51.0" dataX="35.0" dataY="1160.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_151_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_152" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_152"   datasizewidth="1306.0px" datasizeheight="51.0px" datasizewidthpx="1306.0" datasizeheightpx="51.0" dataX="35.0" dataY="1210.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_152_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_153" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_153"   datasizewidth="1306.0px" datasizeheight="51.0px" datasizewidthpx="1306.0" datasizeheightpx="51.0" dataX="35.0" dataY="1260.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_153_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_155" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_155"   datasizewidth="1306.0px" datasizeheight="51.0px" datasizewidthpx="1306.0" datasizeheightpx="51.0" dataX="35.0" dataY="1310.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_155_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_21" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_21"   datasizewidth="81.8px" datasizeheight="18.0px" dataX="82.0" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_21_0">Pagamento</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_52" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_52"   datasizewidth="69.4px" datasizeheight="18.0px" dataX="202.4" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_52_0">Categoria</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_53" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_53"   datasizewidth="81.8px" datasizeheight="18.0px" dataX="394.0" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_53_0">Fornecedor</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_54" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_54"   datasizewidth="71.1px" datasizeheight="18.0px" dataX="534.0" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_54_0">Descri&ccedil;&atilde;o</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_56" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_56"   datasizewidth="96.9px" datasizeheight="18.0px" dataX="394.0" dataY="1027.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_56_0">Fornecedor X</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_57" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_57"   datasizewidth="50.7px" datasizeheight="18.0px" dataX="394.0" dataY="1077.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_57_0">JJDUR</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_58" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_58"   datasizewidth="72.0px" datasizeheight="18.0px" dataX="394.0" dataY="1127.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_58_0">FORN222</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_59" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_59"   datasizewidth="52.5px" datasizeheight="18.0px" dataX="394.0" dataY="1177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_59_0">Tutepiz</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_60" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_60"   datasizewidth="61.4px" datasizeheight="18.0px" dataX="394.0" dataY="1227.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_60_0">MEAL11</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_61" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_61"   datasizewidth="78.2px" datasizeheight="18.0px" dataX="394.0" dataY="1277.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_61_0">TOPFORN</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_62" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_62"   datasizewidth="56.0px" datasizeheight="18.0px" dataX="394.0" dataY="1327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_62_0">COTUE</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_65" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_65"   datasizewidth="110.3px" datasizeheight="18.0px" dataX="534.0" dataY="1027.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_65_0">Contas Energia</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_74" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_74"   datasizewidth="37.4px" datasizeheight="18.0px" dataX="734.0" dataY="1027.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_74_0">Pago</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_87" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_87"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="734.0" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_87_0">Status</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_90" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_90"   datasizewidth="17.8px" datasizeheight="18.0px" dataX="1035.0" dataY="1027.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_90_0">10</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_99" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_99"   datasizewidth="96.1px" datasizeheight="18.0px" dataX="1219.0" dataY="1027.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_99_0">20.099,30 R$</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_100" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_100"   datasizewidth="64.9px" datasizeheight="18.0px" dataX="1250.0" dataY="1077.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_100_0">45,98 R$</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_101" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_101"   datasizewidth="64.9px" datasizeheight="18.0px" dataX="1250.0" dataY="1127.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_101_0">45,69 R$</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_102" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_102"   datasizewidth="87.2px" datasizeheight="18.0px" dataX="1228.0" dataY="1177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_102_0">1.233,77 R$</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_103" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_103"   datasizewidth="73.8px" datasizeheight="18.0px" dataX="1241.0" dataY="1227.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_103_0">789,77 R$</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_104" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_104"   datasizewidth="64.9px" datasizeheight="18.0px" dataX="1250.0" dataY="1277.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_104_0">50,23 R$</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_105" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_105"   datasizewidth="64.9px" datasizeheight="18.0px" dataX="1250.0" dataY="1327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_105_0">25,80 R$</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_149" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_149"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="93.0" dataY="981.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_149_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_150" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_150"   datasizewidth="53.4px" datasizeheight="18.0px" dataX="90.0" dataY="1026.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_150_0">161120</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_151" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_151"   datasizewidth="53.4px" datasizeheight="18.0px" dataX="90.0" dataY="1076.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_151_0">161110</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_152" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_152"   datasizewidth="53.4px" datasizeheight="18.0px" dataX="90.0" dataY="1126.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_152_0">171260</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_153" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_153"   datasizewidth="53.4px" datasizeheight="18.0px" dataX="90.0" dataY="1176.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_153_0">190011</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_154" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_154"   datasizewidth="53.4px" datasizeheight="18.0px" dataX="90.0" dataY="1226.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_154_0">190041</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_155" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_155"   datasizewidth="53.4px" datasizeheight="18.0px" dataX="90.0" dataY="1276.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_155_0">190031</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_156" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_156"   datasizewidth="53.4px" datasizeheight="18.0px" dataX="90.0" dataY="1326.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_156_0">171021</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_147" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_147"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="52.0" dataY="938.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_147_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_182" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_182"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="52.0" dataY="1028.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_182_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_183" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_183"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="52.0" dataY="1078.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_183_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_184" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_184"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="52.0" dataY="1128.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_184_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_185" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_185"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="52.0" dataY="1178.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_185_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_186" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_186"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="52.0" dataY="1228.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_186_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_187" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_187"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="52.0" dataY="1278.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_187_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_188" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_188"   datasizewidth="16.0px" datasizeheight="16.0px" datasizewidthpx="16.0" datasizeheightpx="16.0" dataX="52.0" dataY="1328.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_188_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_106" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_106"   datasizewidth="73.8px" datasizeheight="18.0px" dataX="875.0" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_106_0">Aprovador</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_107" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_107"   datasizewidth="39.1px" datasizeheight="18.0px" dataX="1021.0" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_107_0">Multa</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_108" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_108"   datasizewidth="84.5px" datasizeheight="18.0px" dataX="1115.0" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_108_0">Vencimento</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_109" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_109"   datasizewidth="37.4px" datasizeheight="18.0px" dataX="1274.0" dataY="935.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_109_0">Valor</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_51" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_51"   datasizewidth="25.8px" datasizeheight="18.0px" dataX="201.0" dataY="1027.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_51_0">PIX</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_75" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_75"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="875.0" dataY="1027.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_75_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_91" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_91"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="1115.0" dataY="1027.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_91_0">10/22/2016</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_92" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_92"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="1115.0" dataY="1077.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_92_0">10/22/2016</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_93" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_93"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="1115.0" dataY="1127.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_93_0">10/22/2016</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_94" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_94"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="1115.0" dataY="1177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_94_0">10/22/2016</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_95" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_95"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="1115.0" dataY="1227.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_95_0">10/22/2016</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_96" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_96"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="1115.0" dataY="1277.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_96_0">10/22/2016</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_98" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_98"   datasizewidth="80.1px" datasizeheight="18.0px" dataX="1115.0" dataY="1327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_98_0">10/22/2016</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_110" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_110"   datasizewidth="17.8px" datasizeheight="18.0px" dataX="1035.0" dataY="1077.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_110_0">10</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_111" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_111"   datasizewidth="17.8px" datasizeheight="18.0px" dataX="1035.0" dataY="1127.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_111_0">10</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_112" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_112"   datasizewidth="17.8px" datasizeheight="18.0px" dataX="1035.0" dataY="1177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_112_0">10</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_113" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_113"   datasizewidth="17.8px" datasizeheight="18.0px" dataX="1035.0" dataY="1227.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_113_0">10</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_114" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_114"   datasizewidth="17.8px" datasizeheight="18.0px" dataX="1035.0" dataY="1277.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_114_0">10</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_115" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_115"   datasizewidth="17.8px" datasizeheight="18.0px" dataX="1035.0" dataY="1327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_115_0">10</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_55" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_55"   datasizewidth="32.0px" datasizeheight="18.0px" dataX="201.0" dataY="1077.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_55_0">TED</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_66" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_66"   datasizewidth="94.3px" datasizeheight="18.0px" dataX="534.0" dataY="1077.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_66_0">Suprimentos </span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_76" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_76"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="875.0" dataY="1077.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_76_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_77" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_77"   datasizewidth="73.0px" datasizeheight="18.0px" dataX="734.0" dataY="1077.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_77_0">Agendado</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_63" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_63"   datasizewidth="46.3px" datasizeheight="18.0px" dataX="201.0" dataY="1127.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_63_0">Debito</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_67" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_67"   datasizewidth="99.6px" datasizeheight="18.0px" dataX="534.0" dataY="1127.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_67_0">Materia Prima</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_78" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_78"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="875.0" dataY="1127.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_78_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_79" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_79"   datasizewidth="73.0px" datasizeheight="18.0px" dataX="734.0" dataY="1127.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_79_0">Agendado</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_64" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_64"   datasizewidth="25.8px" datasizeheight="18.0px" dataX="201.0" dataY="1177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_64_0">PIX</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_68" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_68"   datasizewidth="99.6px" datasizeheight="18.0px" dataX="534.0" dataY="1177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_68_0">Materia Prima</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_80" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_80"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="875.0" dataY="1177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_80_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_81" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_81"   datasizewidth="37.4px" datasizeheight="18.0px" dataX="734.0" dataY="1177.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_81_0">Pago</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_69" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_69"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="201.0" dataY="1227.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_69_0">Boleto</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_70" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_70"   datasizewidth="89.8px" datasizeheight="18.0px" dataX="534.0" dataY="1227.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_70_0">Suprimentos</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_88" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_88"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="875.0" dataY="1227.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_88_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_89" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_89"   datasizewidth="37.4px" datasizeheight="18.0px" dataX="734.0" dataY="1227.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_89_0">Pago</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_71" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_71"   datasizewidth="25.8px" datasizeheight="18.0px" dataX="201.0" dataY="1277.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_71_0">PIX</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_72" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_72"   datasizewidth="49.8px" datasizeheight="18.0px" dataX="534.0" dataY="1277.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_72_0">Salario</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_116" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_116"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="875.0" dataY="1277.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_116_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_117" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_117"   datasizewidth="78.3px" datasizeheight="18.0px" dataX="734.0" dataY="1277.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_117_0">Reprovado</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_73" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_73"   datasizewidth="45.4px" datasizeheight="18.0px" dataX="201.0" dataY="1327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_73_0">Boleto</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_118" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_118"   datasizewidth="88.0px" datasizeheight="18.0px" dataX="534.0" dataY="1327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_118_0">Alimenta&ccedil;&atilde;o</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_119" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_119"   datasizewidth="109.4px" datasizeheight="18.0px" dataX="875.0" dataY="1327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_119_0">Michael Adams</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_120" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_120"   datasizewidth="67.6px" datasizeheight="18.0px" dataX="734.0" dataY="1327.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_120_0">Rejeitado</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_121" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_121"   datasizewidth="18.7px" datasizeheight="21.0px" dataX="1306.0" dataY="884.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_121_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_123" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_123"   datasizewidth="14.0px" datasizeheight="21.0px" dataX="57.0" dataY="978.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_123_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_160" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_160"   datasizewidth="938.0px" datasizeheight="39.0px" datasizewidthpx="938.0" datasizeheightpx="39.0" dataX="34.0" dataY="352.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_160_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_173" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_173"   datasizewidth="117.4px" datasizeheight="24.0px" dataX="94.0" dataY="359.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_173_0">Selecionado</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_124" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_124"   datasizewidth="12.0px" datasizeheight="18.0px" dataX="932.0" dataY="361.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_124_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_125" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_125"   datasizewidth="16.0px" datasizeheight="18.0px" dataX="221.0" dataY="362.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_125_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_174" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_174"   datasizewidth="95.1px" datasizeheight="18.0px" dataX="826.0" dataY="362.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_174_0">Mudar Vis&atilde;o</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_175" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_175"   datasizewidth="66.7px" datasizeheight="18.0px" dataX="749.0" dataY="362.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_175_0">Detalhes</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_165" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_165"   datasizewidth="29.0px" datasizeheight="26.0px" datasizewidthpx="29.0" datasizeheightpx="26.0" dataX="55.0" dataY="358.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_165_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_176" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_176"   datasizewidth="8.9px" datasizeheight="18.0px" dataX="64.0" dataY="361.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_176_0">1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_126" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_126"   datasizewidth="16.0px" datasizeheight="18.0px" dataX="1182.0" dataY="362.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_126_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_127" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_127"   datasizewidth="14.0px" datasizeheight="18.0px" dataX="1003.0" dataY="362.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_127_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_129" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_129"   datasizewidth="14.0px" datasizeheight="18.0px" dataX="1072.0" dataY="362.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_129_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_131" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_131"   datasizewidth="16.0px" datasizeheight="18.0px" dataX="1108.0" dataY="362.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_131_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_76" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_76"   datasizewidth="31.0px" datasizeheight="32.0px" datasizewidthpx="31.0" datasizeheightpx="32.0" dataX="1138.0" dataY="355.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_76_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_77" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_77"   datasizewidth="32.0px" datasizeheight="32.0px" datasizewidthpx="32.0" datasizeheightpx="32.0" dataX="1272.0" dataY="355.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_77_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_78" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_78"   datasizewidth="32.0px" datasizeheight="32.0px" datasizewidthpx="32.0" datasizeheightpx="32.0" dataX="1301.0" dataY="355.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_78_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;