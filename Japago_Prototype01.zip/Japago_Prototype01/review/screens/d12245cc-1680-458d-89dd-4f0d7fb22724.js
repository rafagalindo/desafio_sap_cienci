var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Logon Page" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1633307924205-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_323" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1360.0px" datasizeheight="896.0px" >\
        <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="1279.0px" datasizeheight="800.0px" dataX="0.0" dataY="0.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/49976be5-6cf5-48dd-a93d-44dca42bb6a3.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image_2"   datasizewidth="46.2px" datasizeheight="23.2px" dataX="13.2" dataY="11.7"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/02082438-ab91-4617-8004-7a1f9e1cea12.png" />\
          	</div>\
          </div>\
        </div>\
\
        <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input_1"  datasizewidth="265.8px" datasizeheight="35.7px" dataX="494.8" dataY="276.8" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Usu&aacute;rio" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input_2"  datasizewidth="265.8px" datasizeheight="35.7px" dataX="494.8" dataY="322.7" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Senha" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input_3"  datasizewidth="265.8px" datasizeheight="35.7px" dataX="494.8" dataY="397.1" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="PT - Portugu&ecirc;s" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
        <div id="s-Text_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="48.0px" datasizeheight="18.0px" dataX="494.8" dataY="373.6" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_1_0">Idioma</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_1" class="pie button multiline manualfit firer click commentable non-processed" customid="Button_1"   datasizewidth="265.8px" datasizeheight="35.7px" dataX="494.8" dataY="443.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">Entrar</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="112.9px" datasizeheight="18.0px" dataX="567.8" dataY="498.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_2_0">Modificar senha</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_3"   datasizewidth="337.0px" datasizeheight="18.0px" dataX="942.0" dataY="763.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0">Copyright (c) 2016 SAP AG. All rights reserved.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Text_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_9"   datasizewidth="257.9px" datasizeheight="54.0px" dataX="497.0" dataY="196.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_9_0">Japago<br /><br />Solu&ccedil;&otilde;es de Pagamentos Banc&aacute;rios</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;