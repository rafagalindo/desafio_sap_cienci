var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1200" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-80c94bd8-66de-4c16-b852-c81e7430178a" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Aprova&ccedil;&atilde;o - Sucesso" width="1200" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/80c94bd8-66de-4c16-b852-c81e7430178a-1633307924205.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/80c94bd8-66de-4c16-b852-c81e7430178a-1633307924205-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/80c94bd8-66de-4c16-b852-c81e7430178a-1633307924205-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle_1"   datasizewidth="1200.0px" datasizeheight="800.0px" datasizewidthpx="1200.0" datasizeheightpx="800.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="345.0px" datasizeheight="149.0px" >\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="345.0px" datasizeheight="149.0px" datasizewidthpx="345.0" datasizeheightpx="149.0" dataX="427.5" dataY="251.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="206.2px" datasizeheight="24.0px" dataX="496.9" dataY="264.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_1_0"></span><span id="rtr-s-Text_1_1"> </span><span id="rtr-s-Text_1_2">Pagamento Aprovado</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="282.0px" datasizeheight="36.0px" dataX="446.5" dataY="310.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">O Pagamento foi aprovado e ser&aacute; enviado ao banco em breve.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_2" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Text_2"   datasizewidth="24.2px" datasizeheight="21.0px" dataX="733.5" dataY="375.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_2_0">OK</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_1" class="pie path firer ie-background commentable non-processed" customid="Line_1"   datasizewidth="347.0px" datasizeheight="3.0px" dataX="427.0" dataY="366.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="346.0" height="2.0" viewBox="427.0 366.50000000000006 346.0 2.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_1-80c94" d="M427.5 367.50000000000006 L772.5 367.50000000000006 "></path>\
            	    </defs>\
            	    <g>\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_1-80c94" fill="none" stroke-width="1.0" stroke="#E5E5E5" stroke-linecap="butt" filter="none"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_2" class="pie path firer ie-background commentable non-processed" customid="Line_2"   datasizewidth="349.0px" datasizeheight="5.0px" dataX="427.0" dataY="295.5"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="346.0" height="3.0" viewBox="427.0 295.50000000000006 346.0 3.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Line_2-80c94" d="M427.5 297.00000000000006 L772.5 297.00000000000006 "></path>\
            	    </defs>\
            	    <g>\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_2-80c94" fill="none" stroke-width="2.0" stroke="#2B7D2B" stroke-linecap="butt" filter="none"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;